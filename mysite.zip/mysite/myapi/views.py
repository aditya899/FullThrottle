
from rest_framework import viewsets

from .serializers import FullSerializer
from .models import FullThrottle

class FullViewSet(viewsets.ModelViewSet):
	queryset = FullThrottle.objects.all().order_by('item')
	serializer_class = FullSerializer
