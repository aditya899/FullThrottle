from rest_framework import serializers

from .models import FullThrottle

class FullSerializer(serializers.HyperlinkedModelSerializer):
	class Meta:
		model = FullThrottle
		fields = ('item', 'name', 'title')